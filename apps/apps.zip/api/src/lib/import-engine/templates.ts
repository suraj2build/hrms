// ── Universal Master Import Framework — Template Definitions ─────────────────

export interface ColumnSpec {
  key: string
  label: string
  required: boolean
  type: 'string' | 'number' | 'date' | 'boolean' | 'enum'
  enumValues?: string[]
  example: string
  description: string
}

export interface TemplateSpec {
  label: string
  columns: ColumnSpec[]
  sampleRows: Array<Record<string, string>>
}

export const MASTER_TEMPLATES: Record<string, TemplateSpec> = {
  employees: {
    label: 'Employees',
    columns: [
      {
        key: 'employee_code',
        label: 'Employee Code',
        required: true,
        type: 'string',
        example: 'EMP001',
        description: 'Unique identifier for the employee (e.g. EMP001). Will be uppercased.',
      },
      {
        key: 'first_name',
        label: 'First Name',
        required: true,
        type: 'string',
        example: 'Rahul',
        description: 'Employee first name.',
      },
      {
        key: 'last_name',
        label: 'Last Name',
        required: true,
        type: 'string',
        example: 'Sharma',
        description: 'Employee last name.',
      },
      {
        key: 'email',
        label: 'Email',
        required: true,
        type: 'string',
        example: 'rahul.sharma@company.com',
        description: 'Valid work email address. Will be lowercased.',
      },
      {
        key: 'phone',
        label: 'Phone',
        required: false,
        type: 'string',
        example: '9876543210',
        description: 'Contact phone number (optional).',
      },
      {
        key: 'joining_date',
        label: 'Joining Date',
        required: true,
        type: 'date',
        example: '2024-01-15',
        description: 'Date of joining in YYYY-MM-DD format.',
      },
      {
        key: 'employment_type',
        label: 'Employment Type',
        required: true,
        type: 'enum',
        enumValues: ['permanent', 'contract', 'intern', 'probation', 'consultant'],
        example: 'permanent',
        description: 'One of: permanent, contract, intern, probation, consultant.',
      },
      {
        key: 'status',
        label: 'Status',
        required: false,
        type: 'enum',
        enumValues: ['active', 'inactive'],
        example: 'active',
        description: 'Employee status. Defaults to active if blank.',
      },
      {
        key: 'department_code',
        label: 'Department Code',
        required: false,
        type: 'string',
        example: 'DEPT-ENG',
        description: 'Code of an existing department. Warning if not found.',
      },
      {
        key: 'designation_code',
        label: 'Designation Code',
        required: false,
        type: 'string',
        example: 'DESIG-SDE',
        description: 'Code of an existing designation. Warning if not found.',
      },
      {
        key: 'grade_code',
        label: 'Grade Code',
        required: false,
        type: 'string',
        example: 'GRADE-L3',
        description: 'Code of an existing grade (optional).',
      },
      {
        key: 'manager_employee_code',
        label: 'Manager Employee Code',
        required: false,
        type: 'string',
        example: 'EMP010',
        description: 'Employee code of the reporting manager (optional).',
      },
      {
        key: 'work_location_code',
        label: 'Work Location Code',
        required: false,
        type: 'string',
        example: 'LOC-BLR',
        description: 'Code of an existing work location (optional).',
      },
      {
        key: 'pan_number',
        label: 'PAN Number',
        required: false,
        type: 'string',
        example: 'ABCDE1234F',
        description: 'Permanent Account Number. Will be uppercased.',
      },
      {
        key: 'uan_number',
        label: 'UAN Number',
        required: false,
        type: 'string',
        example: '101234567890',
        description: 'Universal Account Number for PF (optional).',
      },
    ],
    sampleRows: [
      {
        employee_code: 'EMP001',
        first_name: 'Rahul',
        last_name: 'Sharma',
        email: 'rahul.sharma@company.com',
        phone: '9876543210',
        joining_date: '2024-01-15',
        employment_type: 'permanent',
        status: 'active',
        department_code: 'DEPT-ENG',
        designation_code: 'DESIG-SDE',
        grade_code: 'GRADE-L3',
        manager_employee_code: 'EMP010',
        work_location_code: 'LOC-BLR',
        pan_number: 'ABCDE1234F',
        uan_number: '101234567890',
      },
      {
        employee_code: 'EMP002',
        first_name: 'Priya',
        last_name: 'Nair',
        email: 'priya.nair@company.com',
        phone: '9123456789',
        joining_date: '2024-03-01',
        employment_type: 'contract',
        status: 'active',
        department_code: 'DEPT-HR',
        designation_code: 'DESIG-HRBP',
        grade_code: '',
        manager_employee_code: '',
        work_location_code: 'LOC-MUM',
        pan_number: '',
        uan_number: '',
      },
    ],
  },

  shifts: {
    label: 'Shifts',
    columns: [
      {
        key: 'code',
        label: 'Code',
        required: true,
        type: 'string',
        example: 'SHIFT-GEN',
        description: 'Unique code for the shift.',
      },
      {
        key: 'name',
        label: 'Name',
        required: true,
        type: 'string',
        example: 'General Shift',
        description: 'Display name of the shift.',
      },
      {
        key: 'start_time',
        label: 'Start Time (HH:MM)',
        required: true,
        type: 'string',
        example: '09:00',
        description: 'Shift start time in HH:MM (24-hour) format.',
      },
      {
        key: 'end_time',
        label: 'End Time (HH:MM)',
        required: true,
        type: 'string',
        example: '18:00',
        description: 'Shift end time in HH:MM (24-hour) format.',
      },
      {
        key: 'grace_minutes',
        label: 'Grace Minutes',
        required: false,
        type: 'number',
        example: '15',
        description: 'Late arrival grace period in minutes. Defaults to 0.',
      },
      {
        key: 'is_night_shift',
        label: 'Is Night Shift',
        required: false,
        type: 'boolean',
        example: 'false',
        description: 'true or false. Set true for overnight shifts.',
      },
      // NOTE: weekly_off_days removed from shift template.
      // Weekly-off days belong to Roster templates, not Shifts.
      // Configure weekly-off patterns using the Rosters CSV template instead.
    ],
    sampleRows: [
      {
        code: 'SHIFT-GEN',
        name: 'General Shift',
        start_time: '09:00',
        end_time: '18:00',
        grace_minutes: '15',
        is_night_shift: 'false',
      },
      {
        code: 'SHIFT-NIGHT',
        name: 'Night Shift',
        start_time: '22:00',
        end_time: '06:00',
        grace_minutes: '10',
        is_night_shift: 'true',
      },
    ],
  },

  departments: {
    label: 'Departments',
    columns: [
      {
        key: 'code',
        label: 'Code',
        required: true,
        type: 'string',
        example: 'DEPT-ENG',
        description: 'Unique department code.',
      },
      {
        key: 'name',
        label: 'Name',
        required: true,
        type: 'string',
        example: 'Engineering',
        description: 'Department display name.',
      },
      {
        key: 'parent_code',
        label: 'Parent Department Code',
        required: false,
        type: 'string',
        example: 'DEPT-TECH',
        description: 'Code of the parent department for nested hierarchies (optional).',
      },
    ],
    sampleRows: [
      { code: 'DEPT-TECH', name: 'Technology', parent_code: '' },
      { code: 'DEPT-ENG', name: 'Engineering', parent_code: 'DEPT-TECH' },
    ],
  },

  designations: {
    label: 'Designations',
    columns: [
      {
        key: 'code',
        label: 'Code',
        required: true,
        type: 'string',
        example: 'DESIG-SDE',
        description: 'Unique designation code.',
      },
      {
        key: 'name',
        label: 'Name',
        required: true,
        type: 'string',
        example: 'Software Development Engineer',
        description: 'Designation display name.',
      },
      {
        key: 'department_code',
        label: 'Department Code',
        required: false,
        type: 'string',
        example: 'DEPT-ENG',
        description: 'Associated department code (optional).',
      },
      {
        key: 'level',
        label: 'Level',
        required: false,
        type: 'string',
        example: 'L3',
        description: 'Designation level or band (optional).',
      },
    ],
    sampleRows: [
      { code: 'DESIG-SDE', name: 'Software Development Engineer', department_code: 'DEPT-ENG', level: 'L3' },
      { code: 'DESIG-HRBP', name: 'HR Business Partner', department_code: 'DEPT-HR', level: 'M1' },
    ],
  },

  sites: {
    label: 'Sites',
    columns: [
      {
        key: 'code',
        label: 'Code',
        required: true,
        type: 'string',
        example: 'SITE-BLR',
        description: 'Unique site code used as a reference key for work locations.',
      },
      {
        key: 'name',
        label: 'Name',
        required: true,
        type: 'string',
        example: 'Bengaluru Campus',
        description: 'Site display name.',
      },
      {
        key: 'location',
        label: 'Location',
        required: false,
        type: 'string',
        example: 'Bengaluru, Karnataka',
        description: 'City/region for display purposes.',
      },
      {
        key: 'timezone',
        label: 'Timezone',
        required: false,
        type: 'string',
        example: 'Asia/Kolkata',
        description: 'IANA timezone name. Defaults to Asia/Kolkata.',
      },
    ],
    sampleRows: [
      { code: 'SITE-BLR', name: 'Bengaluru Campus',  location: 'Bengaluru, Karnataka', timezone: 'Asia/Kolkata' },
      { code: 'SITE-MUM', name: 'Mumbai Office',      location: 'Mumbai, Maharashtra',  timezone: 'Asia/Kolkata' },
    ],
  },

  work_locations: {
    label: 'Work Locations',
    columns: [
      {
        key: 'code',
        label: 'Code',
        required: true,
        type: 'string',
        example: 'LOC-BLR',
        description: 'Unique work location code.',
      },
      {
        key: 'name',
        label: 'Name',
        required: true,
        type: 'string',
        example: 'Bengaluru Office',
        description: 'Work location display name.',
      },
      {
        key: 'site_code',
        label: 'Site Code',
        required: false,
        type: 'string',
        example: 'SITE-BLR',
        description: 'Code of an existing site to link this work location to. Must match the code of a site already created in your organisation.',
      },
      {
        key: 'city',
        label: 'City',
        required: false,
        type: 'string',
        example: 'Bengaluru',
        description: 'City name.',
      },
      {
        key: 'state',
        label: 'State',
        required: false,
        type: 'string',
        example: 'Karnataka',
        description: 'State name.',
      },
      {
        key: 'country',
        label: 'Country',
        required: false,
        type: 'string',
        example: 'India',
        description: 'Country name.',
      },
      {
        key: 'pincode',
        label: 'Pincode',
        required: false,
        type: 'string',
        example: '560001',
        description: 'Postal/PIN code.',
      },
    ],
    sampleRows: [
      { code: 'LOC-BLR', name: 'Bengaluru Office', site_code: 'SITE-BLR', city: 'Bengaluru', state: 'Karnataka', country: 'India', pincode: '560001' },
      { code: 'LOC-MUM', name: 'Mumbai Office',    site_code: 'SITE-MUM', city: 'Mumbai',    state: 'Maharashtra', country: 'India', pincode: '400001' },
    ],
  },

  cost_centers: {
    label: 'Cost Centers',
    columns: [
      {
        key: 'code',
        label: 'Code',
        required: true,
        type: 'string',
        example: 'CC-ENG',
        description: 'Unique cost center code.',
      },
      {
        key: 'name',
        label: 'Name',
        required: true,
        type: 'string',
        example: 'Engineering Cost Center',
        description: 'Cost center display name.',
      },
      {
        key: 'description',
        label: 'Description',
        required: false,
        type: 'string',
        example: 'Covers all engineering teams',
        description: 'Optional description for the cost center.',
      },
    ],
    sampleRows: [
      { code: 'CC-ENG', name: 'Engineering Cost Center', description: 'Covers all engineering teams' },
      { code: 'CC-SALES', name: 'Sales Cost Center', description: 'Covers the sales function' },
    ],
  },

  salary_components: {
    label: 'Salary Components',
    columns: [
      {
        key: 'code',
        label: 'Code',
        required: true,
        type: 'string',
        example: 'SC-BASIC',
        description: 'Unique salary component code.',
      },
      {
        key: 'name',
        label: 'Name',
        required: true,
        type: 'string',
        example: 'Basic Salary',
        description: 'Component display name.',
      },
      {
        key: 'component_type',
        label: 'Component Type',
        required: true,
        type: 'enum',
        enumValues: ['earning', 'deduction', 'employer_contribution'],
        example: 'earning',
        description: 'One of: earning, deduction, employer_contribution.',
      },
      {
        key: 'is_taxable',
        label: 'Is Taxable',
        required: false,
        type: 'boolean',
        example: 'true',
        description: 'true or false. Whether this component is taxable.',
      },
      {
        key: 'is_pf_applicable',
        label: 'Is PF Applicable',
        required: false,
        type: 'boolean',
        example: 'true',
        description: 'true or false. Whether PF is applicable on this component.',
      },
      {
        key: 'is_esi_applicable',
        label: 'Is ESI Applicable',
        required: false,
        type: 'boolean',
        example: 'false',
        description: 'true or false. Whether ESI is applicable on this component.',
      },
    ],
    sampleRows: [
      {
        code: 'SC-BASIC',
        name: 'Basic Salary',
        component_type: 'earning',
        is_taxable: 'true',
        is_pf_applicable: 'true',
        is_esi_applicable: 'false',
      },
      {
        code: 'SC-PF-EE',
        name: 'PF Employee Contribution',
        component_type: 'deduction',
        is_taxable: 'false',
        is_pf_applicable: 'true',
        is_esi_applicable: 'false',
      },
    ],
  },

  leave_types: {
    label: 'Leave Types',
    columns: [
      {
        key: 'name',
        label: 'Name',
        required: true,
        type: 'string',
        example: 'Annual Leave',
        description: 'Leave type name (must be unique within tenant).',
      },
      {
        key: 'is_paid',
        label: 'Is Paid',
        required: false,
        type: 'boolean',
        example: 'true',
        description: 'true or false. Whether the leave is paid.',
      },
      {
        key: 'allow_sandwich',
        label: 'Allow Sandwich',
        required: false,
        type: 'boolean',
        example: 'false',
        description: 'true or false. Whether weekends/holidays between leave days are counted.',
      },
    ],
    sampleRows: [
      { name: 'Annual Leave', is_paid: 'true', allow_sandwich: 'false' },
      { name: 'Sick Leave', is_paid: 'true', allow_sandwich: 'true' },
    ],
  },

  holiday_calendar: {
    label: 'Holiday Calendar',
    columns: [
      {
        key: 'date',
        label: 'Date (YYYY-MM-DD)',
        required: true,
        type: 'date',
        example: '2025-01-26',
        description: 'Holiday date in YYYY-MM-DD format.',
      },
      {
        key: 'name',
        label: 'Holiday Name',
        required: true,
        type: 'string',
        example: 'Republic Day',
        description: 'Name of the holiday.',
      },
      {
        key: 'holiday_type',
        label: 'Holiday Type',
        required: false,
        type: 'enum',
        enumValues: ['national', 'restricted', 'optional'],
        example: 'national',
        description: 'One of: national, restricted, optional.',
      },
    ],
    sampleRows: [
      { date: '2025-01-26', name: 'Republic Day', holiday_type: 'national' },
      { date: '2025-08-15', name: 'Independence Day', holiday_type: 'national' },
    ],
  },

  // ── Enterprise onboarding imports ──────────────────────────────────────────

  employee_compensation: {
    label: 'Employee Compensation',
    columns: [
      {
        key: 'employee_code',
        label: 'Employee Code',
        required: true,
        type: 'string',
        example: 'EMP001',
        description: 'Employee code of an existing employee.',
      },
      {
        key: 'effective_from',
        label: 'Effective From (YYYY-MM-DD)',
        required: true,
        type: 'date',
        example: '2025-04-01',
        description: 'Date from which this compensation is effective (YYYY-MM-DD).',
      },
      {
        key: 'ctc_annual',
        label: 'CTC Annual',
        required: true,
        type: 'number',
        example: '600000',
        description: 'Annual Cost-to-Company in rupees (numeric, no commas).',
      },
      {
        key: 'salary_structure_code',
        label: 'Salary Structure Code',
        required: false,
        type: 'string',
        example: 'SS-DEFAULT',
        description: 'Code of an existing salary structure. Uses tenant default if blank.',
      },
      {
        key: 'notes',
        label: 'Notes',
        required: false,
        type: 'string',
        example: 'Annual revision FY2025',
        description: 'Optional notes about this compensation revision.',
      },
    ],
    sampleRows: [
      {
        employee_code: 'EMP001',
        effective_from: '2025-04-01',
        ctc_annual: '600000',
        salary_structure_code: 'SS-DEFAULT',
        notes: 'Annual revision FY2025',
      },
      {
        employee_code: 'EMP002',
        effective_from: '2025-04-01',
        ctc_annual: '480000',
        salary_structure_code: '',
        notes: '',
      },
    ],
  },

  leave_opening_balances: {
    label: 'Leave Opening Balances',
    columns: [
      {
        key: 'employee_code',
        label: 'Employee Code',
        required: true,
        type: 'string',
        example: 'EMP001',
        description: 'Employee code of an existing employee.',
      },
      {
        key: 'leave_type_name',
        label: 'Leave Type Name',
        required: true,
        type: 'string',
        example: 'Annual Leave',
        description: 'Exact name of an existing leave type.',
      },
      {
        key: 'balance',
        label: 'Balance (days)',
        required: true,
        type: 'number',
        example: '12',
        description: 'Opening balance in days (can be decimal, e.g. 0.5).',
      },
      {
        key: 'year',
        label: 'Year',
        required: false,
        type: 'number',
        example: '2025',
        description: 'Calendar year for this balance. Defaults to current year.',
      },
      {
        key: 'carry_forward_balance',
        label: 'Carry Forward Balance (days)',
        required: false,
        type: 'number',
        example: '3',
        description: 'Days carried forward from the previous year (optional, defaults to 0).',
      },
    ],
    sampleRows: [
      {
        employee_code: 'EMP001',
        leave_type_name: 'Annual Leave',
        balance: '12',
        year: '2025',
        carry_forward_balance: '3',
      },
      {
        employee_code: 'EMP001',
        leave_type_name: 'Sick Leave',
        balance: '6',
        year: '2025',
        carry_forward_balance: '0',
      },
    ],
  },

  shift_assignments: {
    label: 'Shift Assignments',
    columns: [
      {
        key: 'employee_code',
        label: 'Employee Code',
        required: true,
        type: 'string',
        example: 'EMP001',
        description: 'Employee code of an existing employee.',
      },
      {
        key: 'shift_code',
        label: 'Shift Code',
        required: true,
        type: 'string',
        example: 'SHIFT-GEN',
        description: 'Code of an existing shift.',
      },
      {
        key: 'effective_from',
        label: 'Effective From (YYYY-MM-DD)',
        required: true,
        type: 'date',
        example: '2025-04-01',
        description: 'Date from which this shift assignment takes effect (YYYY-MM-DD).',
      },
    ],
    sampleRows: [
      {
        employee_code: 'EMP001',
        shift_code: 'SHIFT-GEN',
        effective_from: '2025-04-01',
      },
      {
        employee_code: 'EMP002',
        shift_code: 'SHIFT-NIGHT',
        effective_from: '2025-04-01',
      },
    ],
  },

  // ── Enterprise Operational Masters ─────────────────────────────────────────

  grades: {
    label: 'Grades / Bands',
    columns: [
      { key: 'code',           label: 'Code',              required: true,  type: 'string', example: 'GRADE-L1',  description: 'Unique grade/band code. Will be uppercased.' },
      { key: 'name',           label: 'Name',              required: true,  type: 'string', example: 'Level 1',   description: 'Display name for the grade.' },
      { key: 'description',    label: 'Description',       required: false, type: 'string', example: 'Junior IC', description: 'Optional description of the grade.' },
      { key: 'level_order',    label: 'Level Order',       required: false, type: 'number', example: '1',         description: 'Numeric order for sorting grades (lower = junior).' },
      { key: 'ctc_min_annual', label: 'Min CTC (Annual)',  required: false, type: 'number', example: '300000',    description: 'Minimum annual CTC for this grade (optional).' },
      { key: 'ctc_max_annual', label: 'Max CTC (Annual)',  required: false, type: 'number', example: '600000',    description: 'Maximum annual CTC for this grade (optional).' },
    ],
    sampleRows: [
      { code: 'GRADE-L1', name: 'Level 1',   description: 'Junior IC',       level_order: '1', ctc_min_annual: '300000',  ctc_max_annual: '600000' },
      { code: 'GRADE-L2', name: 'Level 2',   description: 'Mid-level IC',    level_order: '2', ctc_min_annual: '600000',  ctc_max_annual: '1200000' },
      { code: 'GRADE-M1', name: 'Manager 1', description: 'First-line Mgr',  level_order: '3', ctc_min_annual: '1200000', ctc_max_annual: '2000000' },
    ],
  },

  payroll_groups: {
    label: 'Payroll Groups',
    columns: [
      { key: 'code',             label: 'Code',            required: true,  type: 'string',                               example: 'PG-MONTHLY',  description: 'Unique payroll group code. Will be uppercased.' },
      { key: 'name',             label: 'Name',            required: true,  type: 'string',                               example: 'Monthly Staff', description: 'Display name for the payroll group.' },
      { key: 'cycle_type',       label: 'Cycle Type',      required: false, type: 'enum', enumValues: ['monthly','biweekly','weekly'], example: 'monthly', description: 'Payroll frequency: monthly, biweekly, or weekly.' },
      { key: 'cycle_start_day',  label: 'Cycle Start Day', required: false, type: 'number',                               example: '1',           description: 'First day of the attendance period (1-28). Use 1 for calendar month, 21 for mid-month cycle.' },
      { key: 'cutoff_day',       label: 'Cutoff Day',      required: false, type: 'number',                               example: '25',          description: 'Last day of the attendance period (1-28). E.g. 20 for a 21→20 mid-month cycle.' },
      { key: 'payout_day',       label: 'Payout Day',      required: false, type: 'number',                               example: '1',           description: 'Day of month when salaries are disbursed (1-31).' },
      { key: 'currency_code',    label: 'Currency',        required: false, type: 'string',                               example: 'INR',         description: '3-letter ISO currency code. Defaults to INR.' },
    ],
    sampleRows: [
      { code: 'PG-MONTHLY',   name: 'Monthly Staff',    cycle_type: 'monthly', cycle_start_day: '1',  cutoff_day: '31', payout_day: '5',  currency_code: 'INR' },
      { code: 'PG-MIDMONTH',  name: 'Mid-Month Cycle',  cycle_type: 'monthly', cycle_start_day: '21', cutoff_day: '20', payout_day: '1',  currency_code: 'INR' },
      { code: 'PG-WEEKLY',    name: 'Weekly Field',     cycle_type: 'weekly',  cycle_start_day: '1',  cutoff_day: '5',  payout_day: '7',  currency_code: 'INR' },
    ],
  },

  employment_categories: {
    label: 'Employment Categories',
    columns: [
      { key: 'code',               label: 'Code',              required: true,  type: 'string',  example: 'EC-PERM',  description: 'Unique category code. Will be uppercased.' },
      { key: 'name',               label: 'Name',              required: true,  type: 'string',  example: 'Permanent Regular', description: 'Display name for the employment category.' },
      { key: 'description',        label: 'Description',       required: false, type: 'string',  example: '',         description: 'Optional description.' },
      { key: 'benefits_eligible',  label: 'Benefits Eligible', required: false, type: 'boolean', example: 'true',     description: 'Whether employees in this category are eligible for benefits.' },
      { key: 'pf_applicable',      label: 'PF Applicable',     required: false, type: 'boolean', example: 'true',     description: 'Whether PF deduction applies.' },
      { key: 'esi_applicable',     label: 'ESI Applicable',    required: false, type: 'boolean', example: 'true',     description: 'Whether ESI contribution applies.' },
      { key: 'notice_period_days', label: 'Notice Period (Days)', required: false, type: 'number', example: '30',     description: 'Standard notice period in days.' },
      { key: 'probation_days',     label: 'Probation (Days)',  required: false, type: 'number',  example: '90',       description: 'Probation period in days (0 = no probation).' },
    ],
    sampleRows: [
      { code: 'EC-PERM',     name: 'Permanent Regular',   benefits_eligible: 'true',  pf_applicable: 'true',  esi_applicable: 'true',  notice_period_days: '30', probation_days: '90' },
      { code: 'EC-CONTRACT', name: 'Fixed Term Contract', benefits_eligible: 'false', pf_applicable: 'true',  esi_applicable: 'true',  notice_period_days: '15', probation_days: '0' },
      { code: 'EC-INTERN',   name: 'Intern / Trainee',    benefits_eligible: 'false', pf_applicable: 'false', esi_applicable: 'false', notice_period_days: '7',  probation_days: '0' },
    ],
  },

  statutory_groups: {
    label: 'Statutory Groups',
    columns: [
      { key: 'code',             label: 'Code',              required: true,  type: 'string',  example: 'SG-MH',   description: 'Unique statutory group code. Will be uppercased.' },
      { key: 'name',             label: 'Name',              required: true,  type: 'string',  example: 'Maharashtra', description: 'Group display name (typically state/region).' },
      { key: 'state',            label: 'State',             required: false, type: 'string',  example: 'Maharashtra', description: 'State or region this group covers.' },
      { key: 'pf_enabled',       label: 'PF Enabled',        required: false, type: 'boolean', example: 'true',    description: 'Whether PF applies to employees in this group.' },
      { key: 'esi_enabled',      label: 'ESI Enabled',       required: false, type: 'boolean', example: 'true',    description: 'Whether ESI applies to employees in this group.' },
      { key: 'pt_enabled',       label: 'PT Enabled',        required: false, type: 'boolean', example: 'true',    description: 'Whether Professional Tax applies.' },
      { key: 'lwf_enabled',      label: 'LWF Enabled',       required: false, type: 'boolean', example: 'false',   description: 'Whether Labour Welfare Fund applies.' },
      { key: 'pf_wage_ceiling',  label: 'PF Wage Ceiling',   required: false, type: 'number',  example: '15000',   description: 'Monthly wage ceiling for PF computation (0 = uncapped).' },
      { key: 'esi_wage_ceiling', label: 'ESI Wage Ceiling',  required: false, type: 'number',  example: '21000',   description: 'Monthly gross ceiling for ESI applicability.' },
    ],
    sampleRows: [
      { code: 'SG-MH', name: 'Maharashtra', state: 'Maharashtra', pf_enabled: 'true', esi_enabled: 'true', pt_enabled: 'true',  lwf_enabled: 'false', pf_wage_ceiling: '15000', esi_wage_ceiling: '21000' },
      { code: 'SG-KA', name: 'Karnataka',   state: 'Karnataka',   pf_enabled: 'true', esi_enabled: 'true', pt_enabled: 'true',  lwf_enabled: 'true',  pf_wage_ceiling: '15000', esi_wage_ceiling: '21000' },
      { code: 'SG-DL', name: 'Delhi',       state: 'Delhi',       pf_enabled: 'true', esi_enabled: 'true', pt_enabled: 'false', lwf_enabled: 'false', pf_wage_ceiling: '15000', esi_wage_ceiling: '21000' },
    ],
  },

  asset_categories: {
    label: 'Asset Categories',
    columns: [
      { key: 'code',                label: 'Code',                required: true,  type: 'string', example: 'AC-LAPTOP', description: 'Unique asset category code. Will be uppercased.' },
      { key: 'name',                label: 'Name',                required: true,  type: 'string', example: 'Laptop',    description: 'Asset category display name.' },
      { key: 'description',         label: 'Description',         required: false, type: 'string', example: 'Company-issued laptops and notebooks', description: 'Optional description.' },
      { key: 'depreciation_method', label: 'Depreciation Method', required: false, type: 'enum', enumValues: ['straight_line','declining_balance','none'], example: 'straight_line', description: 'Depreciation method: straight_line, declining_balance, or none.' },
      { key: 'useful_life_years',   label: 'Useful Life (Years)', required: false, type: 'number', example: '3',         description: 'Expected useful life in years for depreciation.' },
      { key: 'requires_return',     label: 'Requires Return',     required: false, type: 'boolean', example: 'true',     description: 'Whether employees must return this asset on separation.' },
    ],
    sampleRows: [
      { code: 'AC-LAPTOP',  name: 'Laptop',          description: 'Company-issued laptops', depreciation_method: 'straight_line', useful_life_years: '3', requires_return: 'true' },
      { code: 'AC-MOBILE',  name: 'Mobile Phone',    description: 'Company mobile devices',  depreciation_method: 'straight_line', useful_life_years: '2', requires_return: 'true' },
      { code: 'AC-VEHICLE', name: 'Vehicle',         description: 'Company vehicles',        depreciation_method: 'declining_balance', useful_life_years: '5', requires_return: 'true' },
    ],
  },

  // ── Payroll Masters ───────────────────────────────────────────────────────────

  salary_structures: {
    label: 'Salary Structures',
    columns: [
      { key: 'code',        label: 'Code',        required: true,  type: 'string',  example: 'SS-SENIOR',    description: 'Unique salary structure code. Will be uppercased.' },
      { key: 'name',        label: 'Name',        required: true,  type: 'string',  example: 'Senior Engineer Package', description: 'Display name for the salary structure.' },
      { key: 'description', label: 'Description', required: false, type: 'string',  example: 'Band L3-L4 CTC structure', description: 'Optional description.' },
      { key: 'is_default',  label: 'Is Default',  required: false, type: 'boolean', example: 'false', description: 'Set to true to make this the tenant-default structure. Only one may be default.' },
    ],
    sampleRows: [
      { code: 'SS-DEFAULT', name: 'Standard Package',   description: 'Default CTC structure', is_default: 'true' },
      { code: 'SS-SENIOR',  name: 'Senior Engineer',    description: 'Band L3-L4',            is_default: 'false' },
      { code: 'SS-MGMT',    name: 'Management Package', description: 'Manager band',          is_default: 'false' },
    ],
  },

  // ── Onboarding Governance ─────────────────────────────────────────────────────

  compensation_revisions: {
    label: 'Compensation Revisions',
    columns: [
      { key: 'employee_code',  label: 'Employee Code',   required: true,  type: 'string', example: 'EMP001', description: 'Employee code identifying the revision target.' },
      { key: 'revision_type',  label: 'Revision Type',   required: true,  type: 'enum',   enumValues: ['increment','promotion','restructure','correction','transfer'], example: 'increment', description: 'Type of compensation revision.' },
      { key: 'effective_date', label: 'Effective Date',  required: true,  type: 'date',   example: '2025-04-01', description: 'Date from which the new CTC takes effect (YYYY-MM-DD).' },
      { key: 'new_ctc_annual', label: 'New Annual CTC',  required: true,  type: 'number', example: '1200000', description: 'New annual CTC in rupees.' },
      { key: 'reason',         label: 'Reason',          required: true,  type: 'string', example: 'Annual increment cycle FY2025', description: 'Business reason for the revision.' },
      { key: 'notes',          label: 'Notes',           required: false, type: 'string', example: 'Approved in April review', description: 'Optional free-text notes.' },
    ],
    sampleRows: [
      { employee_code: 'EMP001', revision_type: 'increment',   effective_date: '2025-04-01', new_ctc_annual: '1200000', reason: 'Annual increment FY2025' },
      { employee_code: 'EMP002', revision_type: 'promotion',   effective_date: '2025-04-01', new_ctc_annual: '1800000', reason: 'Promotion to Senior Engineer' },
      { employee_code: 'EMP003', revision_type: 'correction',  effective_date: '2025-01-01', new_ctc_annual: '950000',  reason: 'Joining CTC correction' },
    ],
  },

  // ── Reference Data ─────────────────────────────────────────────────────────────

  document_types: {
    label: 'Document Types',
    columns: [
      { key: 'code',           label: 'Code',           required: true,  type: 'string',  example: 'DT-AADHAR',  description: 'Unique document type code. Will be uppercased.' },
      { key: 'name',           label: 'Name',           required: true,  type: 'string',  example: 'Aadhaar Card', description: 'Display name for the document type.' },
      { key: 'description',    label: 'Description',    required: false, type: 'string',  example: 'Government-issued identity', description: 'Optional description.' },
      { key: 'is_mandatory',   label: 'Is Mandatory',   required: false, type: 'boolean', example: 'true',       description: 'Whether this document is mandatory for all employees.' },
    ],
    sampleRows: [
      { code: 'DT-AADHAR', name: 'Aadhaar Card',   description: 'Govt identity (12-digit)',  is_mandatory: 'true' },
      { code: 'DT-PAN',    name: 'PAN Card',        description: 'Tax identity',             is_mandatory: 'true' },
      { code: 'DT-OFFER',  name: 'Offer Letter',    description: 'Signed offer letter',      is_mandatory: 'false' },
    ],
  },

  identity_types: {
    label: 'Identity Types',
    columns: [
      { key: 'code',        label: 'Code',        required: true,  type: 'string', example: 'ID-PASSPORT', description: 'Unique identity type code. Will be uppercased.' },
      { key: 'name',        label: 'Name',        required: true,  type: 'string', example: 'Passport',    description: 'Display name for the identity type.' },
      { key: 'description', label: 'Description', required: false, type: 'string', example: 'International travel document', description: 'Optional description.' },
    ],
    sampleRows: [
      { code: 'ID-PASSPORT', name: 'Passport',        description: 'International travel document' },
      { code: 'ID-DRIVING',  name: 'Driving Licence', description: 'State-issued driving licence' },
      { code: 'ID-VOTER',    name: 'Voter ID',         description: 'Election Commission card' },
    ],
  },

  relationship_types: {
    label: 'Relationship Types',
    columns: [
      { key: 'code', label: 'Code', required: true,  type: 'string', example: 'REL-SPOUSE',  description: 'Unique relationship type code. Will be uppercased.' },
      { key: 'name', label: 'Name', required: true,  type: 'string', example: 'Spouse',      description: 'Display name for the relationship type.' },
    ],
    sampleRows: [
      { code: 'REL-SPOUSE', name: 'Spouse' },
      { code: 'REL-FATHER', name: 'Father' },
      { code: 'REL-MOTHER', name: 'Mother' },
      { code: 'REL-SON',    name: 'Son' },
      { code: 'REL-DAUGHTER', name: 'Daughter' },
    ],
  },
}

// ── CSV Generation ────────────────────────────────────────────────────────────

function escapeCsvField(val: string): string {
  if (val.includes(',') || val.includes('"') || val.includes('\n')) {
    return `"${val.replace(/"/g, '""')}"`
  }
  return val
}

export function generateCSV(masterType: string): string {
  const spec = MASTER_TEMPLATES[masterType]
  if (!spec) return ''

  const lines: string[] = []

  // Instruction comment row (not a real data row — starts with #)
  const instructions = [
    `# HRMS Import Template: ${spec.label}`,
    `# Fields marked * are required. Do not modify the header row.`,
    `# Date fields must be in YYYY-MM-DD format. Boolean fields: true or false.`,
    `# Remove this comment row and any extra blank rows before importing.`,
  ]
  lines.push(...instructions)

  // Description row
  const descRow = spec.columns.map((c) => escapeCsvField(c.description))
  lines.push(`# ${descRow.join(',')}`)

  // Header row — mark required columns with *
  const headerRow = spec.columns.map((c) =>
    escapeCsvField(c.required ? `${c.key} *` : c.key),
  )
  lines.push(headerRow.join(','))

  // Sample data rows
  for (const row of spec.sampleRows) {
    const dataRow = spec.columns.map((c) => escapeCsvField(row[c.key] ?? ''))
    lines.push(dataRow.join(','))
  }

  return lines.join('\n')
}

export function getTemplateSpec(masterType: string): TemplateSpec | null {
  return MASTER_TEMPLATES[masterType] ?? null
}
