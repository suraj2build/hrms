/**
 * Comp Off (Compensatory Off) Routes
 *
 * Automates the compensatory-off lifecycle:
 *   1. Detect: scan attendance_daily for worked_on_weekly_off / worked_on_holiday
 *      and create pending CO requests for each qualifying date.
 *   2. Approve: credit leave balance via leave_accrual_ledger with expiry.
 *   3. Reject: mark request as rejected; no balance change.
 *
 * Endpoints:
 *   POST /attendance/comp-off/generate
 *       Detect qualifying dates for one employee (or all employees) and create
 *       pending comp_off_requests rows.  Idempotent — existing rows are skipped.
 *
 *   GET  /attendance/comp-off
 *       List comp_off_requests.  Employees see their own; HR sees all.
 *       Supports ?status=pending|approved|rejected filter.
 *
 *   POST /attendance/comp-off/:id/approve
 *       HR/manager approves a request.  Credits days_to_credit to the employee's
 *       leave_accrual_ledger with an expiry date derived from the CO leave type's
 *       expiry_days rule (falls back to 90 days).
 *
 *   POST /attendance/comp-off/:id/reject
 *       HR/manager rejects a request with optional notes.
 *
 * Access:
 *   read  — any authenticated user (employees see own, admins see all)
 *   write — hr_admin / super_admin / manager
 */

import type { FastifyInstance } from 'fastify'
import { z }                    from 'zod'
import { logAction }            from '../../lib/audit-service.js'

const generateSchema = z.object({
  employee_id:   z.string().uuid().optional(),   // omit = all active employees
  from_date:     z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  to_date:       z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  leave_type_id: z.string().uuid().optional(),   // the "Comp Off" leave type UUID
})

const approveSchema = z.object({
  notes: z.string().max(500).optional(),
})

export default async function compOffRoute(fastify: FastifyInstance) {
  const auth       = { preHandler: [fastify.authenticate] }
  const hrAdminAuth = {
    preHandler: [
      fastify.authenticate,
      async (req: any, reply: any) => {
        if (!['super_admin', 'hr_admin', 'manager'].includes(req.userRole)) {
          return reply.code(403).send({ error: 'FORBIDDEN', message: 'Manager or HR admin access required' })
        }
      },
    ],
  }

  // ── POST /attendance/comp-off/generate ──────────────────────────────────
  // Scan attendance_daily for work-on-holiday / work-on-weekly-off and create
  // comp_off_requests rows.  Existing rows (same employee + worked_date) are
  // skipped due to the UNIQUE constraint — safe to call repeatedly.
  fastify.post('/attendance/comp-off/generate', hrAdminAuth, async (req: any, reply) => {
    const parsed = generateSchema.safeParse(req.body)
    if (!parsed.success) {
      return reply.code(400).send({
        error:   'VALIDATION_ERROR',
        message: parsed.error.issues[0]?.message,
      })
    }

    const { employee_id, from_date, to_date, leave_type_id } = parsed.data

    // Fetch qualifying attendance_daily rows
    let query = fastify.supabase
      .from('attendance_daily')
      .select('employee_id, date, worked_on_weekly_off, worked_on_holiday')
      .eq('tenant_id', req.tenantId)
      .gte('date', from_date)
      .lte('date', to_date)
      .or('worked_on_weekly_off.eq.true,worked_on_holiday.eq.true')

    if (employee_id) {
      query = query.eq('employee_id', employee_id)
    }

    const { data: qualifying, error: fetchErr } = await query
    if (fetchErr) {
      return reply.code(500).send({ error: 'QUERY_FAILED', message: fetchErr.message })
    }

    if (!qualifying?.length) {
      return reply.send({ data: { created: 0, skipped: 0, message: 'No qualifying attendance records found' } })
    }

    // Build insert rows — DB UNIQUE constraint will reject duplicates
    const rows = (qualifying as Array<{
      employee_id:          string
      date:                 string
      worked_on_weekly_off: boolean
      worked_on_holiday:    boolean
    }>).map(row => ({
      tenant_id:     req.tenantId,
      employee_id:   row.employee_id,
      worked_date:   row.date,
      worked_reason: row.worked_on_holiday ? 'holiday' : 'weekly_off',
      leave_type_id: leave_type_id ?? null,
      days_to_credit: 1.0,
      status:         'pending',
      created_by:     req.userId,
    }))

    // Use upsert with ignoreDuplicates to handle existing rows gracefully
    const { data: inserted, error: insertErr } = await fastify.supabase
      .from('comp_off_requests')
      .upsert(rows, {
        onConflict:       'tenant_id,employee_id,worked_date',
        ignoreDuplicates: true,
      })
      .select('id')

    if (insertErr) {
      return reply.code(500).send({ error: 'INSERT_FAILED', message: insertErr.message })
    }

    const created = (inserted as any[])?.length ?? 0
    const skipped = rows.length - created

    await logAction(fastify.supabase, {
      tenantId:    req.tenantId,
      tableName:   'comp_off_requests',
      recordId:    req.tenantId,
      action:      'INSERT',
      performedBy: req.userId,
      newData:     { created, skipped, from_date, to_date, employee_id: employee_id ?? 'all' },
    })

    return reply.code(201).send({ data: { created, skipped } })
  })

  // ── GET /attendance/comp-off ─────────────────────────────────────────────
  fastify.get('/attendance/comp-off', auth, async (req: any, reply) => {
    const statusFilter = (req.query as any).status as string | undefined
    const isAdmin      = ['super_admin', 'hr_admin', 'manager'].includes(req.userRole)

    let q = fastify.supabase
      .from('comp_off_requests')
      .select(`
        id, worked_date, worked_reason, days_to_credit, status, notes,
        created_at, reviewed_at,
        leave_types(id, name),
        employees!inner(id, first_name, last_name, employee_code)
      `)
      .eq('tenant_id', req.tenantId)
      .order('worked_date', { ascending: false })

    // Non-admins see only their own requests
    if (!isAdmin) {
      const { data: profile } = await fastify.supabase
        .from('profiles')
        .select('employee_id')
        .eq('id', req.userId)
        .eq('tenant_id', req.tenantId)
        .single()

      if (!profile?.employee_id) {
        return reply.send({ data: [] })
      }
      q = q.eq('employee_id', profile.employee_id)
    }

    if (statusFilter && ['pending', 'approved', 'rejected'].includes(statusFilter)) {
      q = q.eq('status', statusFilter)
    }

    const { data, error } = await q
    if (error) {
      return reply.code(500).send({ error: 'QUERY_FAILED', message: error.message })
    }

    const rows = ((data ?? []) as any[]).map(row => ({
      id:              row.id,
      worked_date:     row.worked_date,
      worked_reason:   row.worked_reason,
      days_to_credit:  row.days_to_credit,
      status:          row.status,
      notes:           row.notes,
      created_at:      row.created_at,
      reviewed_at:     row.reviewed_at,
      leave_type:      row.leave_types ?? null,
      employee: row.employees ? {
        id:            row.employees.id,
        name:          `${row.employees.first_name} ${row.employees.last_name}`,
        employee_code: row.employees.employee_code,
      } : null,
    }))

    return reply.send({ data: rows })
  })

  // ── POST /attendance/comp-off/:id/approve ────────────────────────────────
  fastify.post('/attendance/comp-off/:id/approve', hrAdminAuth, async (req: any, reply) => {
    const { id } = req.params as { id: string }

    const parsed = approveSchema.safeParse(req.body ?? {})
    if (!parsed.success) {
      return reply.code(400).send({ error: 'VALIDATION_ERROR', message: parsed.error.issues[0]?.message })
    }

    // Fetch the CO request
    const { data: co, error: fetchErr } = await fastify.supabase
      .from('comp_off_requests')
      .select('id, employee_id, leave_type_id, worked_date, days_to_credit, status, tenant_id')
      .eq('id', id)
      .eq('tenant_id', req.tenantId)
      .maybeSingle()

    if (fetchErr || !co) {
      return reply.code(404).send({ error: 'NOT_FOUND', message: 'Comp off request not found' })
    }
    if ((co as any).status !== 'pending') {
      return reply.code(409).send({
        error:   'INVALID_STATE',
        message: `Request is already ${(co as any).status}`,
      })
    }

    const now = new Date().toISOString()

    // ── Determine expiry date ────────────────────────────────────────────
    // Prefer expiry_days from the linked leave_policy_rules for the CO leave type.
    // Fall back to the legacy leave_policies table, then to 90 days.
    let expiryDays = 90
    if ((co as any).leave_type_id) {
      const { data: rule } = await fastify.supabase
        .from('leave_policy_rules')
        .select('expiry_days')
        .eq('tenant_id', req.tenantId)
        .eq('leave_type_id', (co as any).leave_type_id)
        .not('expiry_days', 'is', null)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle()

      if (!(rule as any)?.expiry_days) {
        // Try legacy leave_policies
        const { data: legacyRule } = await fastify.supabase
          .from('leave_policies')
          .select('expiry_days')
          .eq('tenant_id', req.tenantId)
          .eq('leave_type_id', (co as any).leave_type_id)
          .maybeSingle()
        if ((legacyRule as any)?.expiry_days) {
          expiryDays = Number((legacyRule as any).expiry_days)
        }
      } else {
        expiryDays = Number((rule as any).expiry_days)
      }
    }

    const expiresOn = new Date(`${(co as any).worked_date}T12:00:00.000Z`)
    expiresOn.setUTCDate(expiresOn.getUTCDate() + expiryDays)
    const expiresOnStr = expiresOn.toISOString().slice(0, 10)

    // ── Credit balance via leave_accrual_ledger ──────────────────────────
    if ((co as any).leave_type_id) {
      const { error: ledgerErr } = await fastify.supabase
        .from('leave_accrual_ledger')
        .upsert(
          {
            tenant_id:     req.tenantId,
            employee_id:   (co as any).employee_id,
            leave_type_id: (co as any).leave_type_id,
            accrual_type:  'co_grant',
            days:          Number((co as any).days_to_credit),
            year:          new Date((co as any).worked_date + 'T12:00:00Z').getFullYear(),
            accrued_on:    now.slice(0, 10),   // was: run_date (wrong column name)
            expires_on:    expiresOnStr,
            is_expired:    false,
            notes:         `CO for work on ${(co as any).worked_date}`,  // was: note
          },
          {
            // co_grant is NOT covered by the partial unique index so this is a
            // plain insert semantically; ignoreDuplicates is a safety net only.
            onConflict:       'tenant_id,employee_id,leave_type_id,year,accrual_type,accrued_on',
            ignoreDuplicates: true,
          },
        )

      if (ledgerErr) {
        req.log.error({ err: ledgerErr }, 'comp-off ledger insert failed')
        return reply.code(500).send({ error: 'LEDGER_FAILED', message: 'Failed to credit leave balance' })
      }

      // Also upsert employee_leave_balance so balance is immediately visible
      const creditYear = new Date((co as any).worked_date + 'T12:00:00Z').getFullYear()
      try {
        await fastify.supabase.rpc('credit_leave_balance', {
          p_tenant_id:     req.tenantId,
          p_employee_id:   (co as any).employee_id,
          p_leave_type_id: (co as any).leave_type_id,
          p_days:          Number((co as any).days_to_credit),
          p_year:          creditYear,
        })
      } catch {
        // non-fatal if RPC not yet created
      }
    }

    // ── Mark request as approved ─────────────────────────────────────────
    const { error: updateErr } = await fastify.supabase
      .from('comp_off_requests')
      .update({
        status:      'approved',
        reviewed_by: req.userId,
        reviewed_at: now,
        notes:       parsed.data.notes ?? null,
      })
      .eq('id', id)
      .eq('tenant_id', req.tenantId)

    if (updateErr) {
      return reply.code(500).send({ error: 'UPDATE_FAILED', message: updateErr.message })
    }

    await logAction(fastify.supabase, {
      tenantId:    req.tenantId,
      tableName:   'comp_off_requests',
      recordId:    id,
      action:      'UPDATE',
      performedBy: req.userId,
      oldData:     { status: 'pending' },
      newData:     { status: 'approved', expires_on: expiresOnStr, days: (co as any).days_to_credit },
    })

    return reply.send({
      data: {
        id,
        status:      'approved',
        expires_on:  expiresOnStr,
        days_credited: Number((co as any).days_to_credit),
      },
    })
  })

  // ── POST /attendance/comp-off/:id/reject ─────────────────────────────────
  fastify.post('/attendance/comp-off/:id/reject', hrAdminAuth, async (req: any, reply) => {
    const { id } = req.params as { id: string }

    const parsed = approveSchema.safeParse(req.body ?? {})  // notes optional
    if (!parsed.success) {
      return reply.code(400).send({ error: 'VALIDATION_ERROR', message: parsed.error.issues[0]?.message })
    }

    const { data: co } = await fastify.supabase
      .from('comp_off_requests')
      .select('id, status')
      .eq('id', id)
      .eq('tenant_id', req.tenantId)
      .maybeSingle()

    if (!co) {
      return reply.code(404).send({ error: 'NOT_FOUND', message: 'Comp off request not found' })
    }
    if ((co as any).status !== 'pending') {
      return reply.code(409).send({
        error:   'INVALID_STATE',
        message: `Request is already ${(co as any).status}`,
      })
    }

    const now = new Date().toISOString()

    const { error: updateErr } = await fastify.supabase
      .from('comp_off_requests')
      .update({
        status:      'rejected',
        reviewed_by: req.userId,
        reviewed_at: now,
        notes:       parsed.data.notes ?? null,
      })
      .eq('id', id)
      .eq('tenant_id', req.tenantId)

    if (updateErr) {
      return reply.code(500).send({ error: 'UPDATE_FAILED', message: updateErr.message })
    }

    await logAction(fastify.supabase, {
      tenantId:    req.tenantId,
      tableName:   'comp_off_requests',
      recordId:    id,
      action:      'UPDATE',
      performedBy: req.userId,
      oldData:     { status: 'pending' },
      newData:     { status: 'rejected' },
    })

    return reply.code(200).send({ data: { id, status: 'rejected' } })
  })
}
